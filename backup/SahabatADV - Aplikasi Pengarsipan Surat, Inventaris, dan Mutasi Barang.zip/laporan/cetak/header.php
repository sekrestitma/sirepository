<?php require_once "../../utils.php"; ?>
<div id="kop" class="d-flex justify-content-center gap-5">
    <img src="../../assets/img/kotabaru.png" height="150" alt="">
    <div class="text-center" style="flex: 1;">
        <h2>
            KANTOR KECAMATAN KELUMPANG UTARA
            <br>
            PEMERINTAH KABUPATEN KOTABARU
        </h2>
        <p>
            Alamat: Jl. Burung Lepas RT. 03 Pudi, Kotabaru Kalimantan Selatan Kode Pos 72165
        </p>
    </div>
</div>