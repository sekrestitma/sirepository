<div style="display: flex; justify-content: end;">
    <div style="text-align: center; margin-top: 20px; padding: 10px; width: 200px;">
        <span>Kotabaru, <?= Date('d') ?> <?= BULAN_DALAM_INDONESIA[Date('m') - 1] ?> <?= Date('Y') ?></span>
        <br>
        <span>Mengetahui</span>
        <br><br><br><br><br>
        <span>ADMIN</span>
    </div>
</div>