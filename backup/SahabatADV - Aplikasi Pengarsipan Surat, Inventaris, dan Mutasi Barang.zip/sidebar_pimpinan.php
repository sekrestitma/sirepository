<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link" href="index.php">
                <i class="bi bi-grid"></i>
                <span>Beranda</span>
            </a>
        </li>
        <li class="nav-item">
            <a id="surat_disposisi" class="nav-link collapsed" href="index.php?page=surat_disposisi&item=tampil_surat_disposisi">
                <i class="ri ri-mail-line"></i>
                <span>Surat Disposisi</span>
            </a>
        </li>
        <li class="nav-item">
            <a id="laporan" class="nav-link collapsed" href="index.php?page=laporan">
                <i class="bi bi-journal-text"></i>
                <span>Laporan</span>
            </a>
        </li><!-- End Tampil Surat Nav -->
    </ul>

</aside><!-- End Sidebar-->